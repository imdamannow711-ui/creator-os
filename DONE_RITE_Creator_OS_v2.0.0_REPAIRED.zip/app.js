(() => {
  // build-entry.jsx
  var COLORS = {
    void: "#080a0e",
    panel: "#11151c",
    panel2: "#171c25",
    line: "#2a3442",
    chrome: "#c4ccd6",
    dim: "#8793a1",
    text: "#eef3f8",
    blue: "#1e7bff",
    blueGlow: "#58a6ff",
    green: "#2bd97c",
    amber: "#ffb020",
    red: "#ff4d5a"
  };
  var STORAGE_KEY = "done-rite-creator-os:v2";
  var LEGACY_STORAGE_KEYS = ["done-rite-creator-os:v1"];
  var RECOVERY_KEY = "done-rite-creator-os:recovery:v2";
  var STORAGE_VERSION = 2;
  var CATEGORIES = [
    "Electronics & Gadgets",
    "Kitchen",
    "Home",
    "Outdoor",
    "Apparel",
    "Wellness & Supplements",
    "Oral & Dental",
    "Skincare",
    "Body-Applied Products",
    "Kids' Products",
    "Tools",
    "Lifestyle"
  ];
  var DEFAULT_TASKS = [
    { id: "shop", label: "Check TikTok Shop", done: false },
    { id: "samples", label: "Review sample opportunities", done: false },
    { id: "create", label: "Create one product package", done: false },
    { id: "comments", label: "Reply to important comments", done: false },
    { id: "results", label: "Record results and new ideas", done: false }
  ];
  var EMPTY_FORM = {
    productName: "",
    category: "Electronics & Gadgets",
    verifiedFeatures: "",
    funnel: "BOF",
    duration: "15",
    platform: "TikTok Shop",
    sampleReceived: false,
    batteryPowered: false
  };
  var EMPTY_MONEY = {
    type: "Affiliate revenue",
    platform: "TikTok Shop",
    amount: "",
    date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
    note: ""
  };
  var CSS = `
  * { box-sizing: border-box; }
  .dr-shell {
    min-height: 100vh;
    background:
      radial-gradient(circle at 50% -10%, rgba(30,123,255,.22), transparent 34rem),
      ${COLORS.void};
    color: ${COLORS.text};
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    padding-bottom: 86px;
  }
  .dr-wrap { width: min(820px, 100%); margin: 0 auto; padding: 16px; }
  .dr-header {
    position: sticky; top: 0; z-index: 20;
    border-bottom: 1px solid ${COLORS.line};
    background: rgba(8,10,14,.94); backdrop-filter: blur(14px);
  }
  .dr-brand { display:flex; align-items:center; gap:10px; min-height:64px; }
  .dr-bolt { color:${COLORS.blueGlow}; font-size:24px; filter:drop-shadow(0 0 8px ${COLORS.blue}); }
  .dr-title { margin:0; font-size:15px; letter-spacing:.13em; text-transform:uppercase; }
  .dr-tagline { margin:3px 0 0; color:${COLORS.dim}; font-size:12px; }
  .dr-tabs { display:flex; gap:8px; overflow-x:auto; padding:10px 16px; scrollbar-width:none; }
  .dr-tabs::-webkit-scrollbar { display:none; }
  .dr-tab, .dr-button, .dr-copy, .dr-danger {
    min-height:44px; border-radius:12px; border:1px solid ${COLORS.line};
    padding:10px 14px; font:inherit; font-weight:800; cursor:pointer;
    -webkit-tap-highlight-color:transparent;
  }
  .dr-tab { flex:0 0 auto; color:${COLORS.chrome}; background:${COLORS.panel}; }
  .dr-tab[aria-selected="true"] { color:white; background:${COLORS.blue}; border-color:${COLORS.blueGlow}; }
  .dr-button { width:100%; background:linear-gradient(135deg, ${COLORS.blue}, #0f4fa8); color:white; }
  .dr-button:disabled { opacity:.45; cursor:not-allowed; }
  .dr-copy { background:${COLORS.panel2}; color:${COLORS.blueGlow}; }
  .dr-danger { background:transparent; color:${COLORS.red}; }
  .dr-grid { display:grid; grid-template-columns:repeat(2, minmax(0,1fr)); gap:12px; }
  .dr-card { background:rgba(17,21,28,.96); border:1px solid ${COLORS.line}; border-radius:18px; padding:16px; }
  .dr-card + .dr-card { margin-top:12px; }
  .dr-metric { font-size:28px; font-weight:900; color:${COLORS.blueGlow}; }
  .dr-label { display:block; margin:0 0 7px; color:${COLORS.chrome}; font-size:12px; font-weight:900; letter-spacing:.07em; text-transform:uppercase; }
  .dr-help { color:${COLORS.dim}; font-size:13px; line-height:1.5; }
  .dr-input, .dr-select, .dr-textarea {
    width:100%; border:1px solid ${COLORS.line}; border-radius:12px;
    background:${COLORS.panel2}; color:${COLORS.text}; padding:13px;
    font:inherit; font-size:16px; outline:none;
  }
  .dr-input:focus, .dr-select:focus, .dr-textarea:focus { border-color:${COLORS.blueGlow}; box-shadow:0 0 0 3px rgba(88,166,255,.14); }
  .dr-textarea { min-height:112px; resize:vertical; }
  .dr-field { margin-bottom:14px; }
  .dr-row { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
  .dr-row > * { flex:1 1 150px; }
  .dr-check { display:flex; gap:10px; align-items:flex-start; color:${COLORS.chrome}; font-size:14px; line-height:1.4; }
  .dr-check input { width:20px; height:20px; margin:0; accent-color:${COLORS.blue}; flex:0 0 auto; }
  .dr-output { white-space:pre-wrap; line-height:1.55; font-size:14px; color:${COLORS.text}; }
  .dr-output-head { display:flex; gap:10px; align-items:center; justify-content:space-between; margin-bottom:10px; }
  .dr-output-head .dr-copy { flex:0 0 auto; min-height:38px; padding:8px 12px; }
  .dr-flag { border-left:4px solid ${COLORS.amber}; }
  .dr-block { border-left-color:${COLORS.red}; }
  .dr-clear { border-left:4px solid ${COLORS.green}; }
  .dr-pill { display:inline-flex; border:1px solid ${COLORS.line}; border-radius:999px; padding:5px 9px; color:${COLORS.chrome}; background:${COLORS.panel2}; font-size:12px; }
  .dr-list { display:grid; gap:9px; }
  .dr-item { display:flex; align-items:flex-start; justify-content:space-between; gap:10px; padding:12px; border:1px solid ${COLORS.line}; border-radius:12px; background:${COLORS.panel2}; }
  .dr-item-main { min-width:0; flex:1; }
  .dr-item-title { font-weight:800; overflow-wrap:anywhere; }
  .dr-status { min-height:24px; margin:10px 0; text-align:center; color:${COLORS.green}; font-weight:800; }
  .dr-nav {
    position:fixed; left:0; right:0; bottom:0; z-index:25;
    border-top:1px solid ${COLORS.line}; background:rgba(17,21,28,.97);
    padding-bottom:env(safe-area-inset-bottom);
  }
  .dr-nav-inner { width:min(820px,100%); margin:0 auto; display:flex; overflow-x:auto; }
  .dr-nav button { flex:1 0 74px; min-height:62px; border:0; background:transparent; color:${COLORS.dim}; font:inherit; font-size:11px; font-weight:800; }
  .dr-nav button[aria-current="page"] { color:${COLORS.blueGlow}; }
  h2 { margin:0 0 6px; font-size:22px; }
  h3 { margin:0; font-size:15px; }
  @media (max-width:540px) { .dr-grid { grid-template-columns:1fr 1fr; } .dr-wrap { padding:12px; } }
`;
  function uid() {
    return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  }
  function mergeUnique(items, keyFor) {
    const seen = /* @__PURE__ */ new Set();
    return items.filter((item) => {
      if (!item || typeof item !== "object") return false;
      const key = keyFor(item);
      if (!key || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
  function normalizeWorkspace(data = {}) {
    return {
      version: Number(data.version) || 1,
      saved: Array.isArray(data.saved) ? data.saved : [],
      products: Array.isArray(data.products) ? data.products : [],
      tasks: Array.isArray(data.tasks) && data.tasks.length ? data.tasks : DEFAULT_TASKS,
      moneyRows: Array.isArray(data.moneyRows) ? data.moneyRows : [],
      form: { ...EMPTY_FORM, ...data.form || data.draft?.form || {} },
      pkg: data.pkg || data.draft?.pkg || null,
      moneyForm: { ...EMPTY_MONEY, ...data.moneyForm || data.draft?.moneyForm || {} },
      checkText: String(data.checkText || data.draft?.checkText || ""),
      search: String(data.search || data.draft?.search || ""),
      draftProductId: data.draftProductId || data.draft?.draftProductId || null,
      lastTab: data.lastTab || "home"
    };
  }
  function readWorkspace() {
    const found = [];
    const usedKeys = [];
    const candidateKeys = [STORAGE_KEY, ...LEGACY_STORAGE_KEYS];
    for (let index = 0; index < localStorage.length; index += 1) {
      const key = localStorage.key(index);
      if (key && /done.?rite.*creator.?os/i.test(key) && key !== RECOVERY_KEY && !candidateKeys.includes(key)) {
        candidateKeys.push(key);
      }
    }
    candidateKeys.forEach((key) => {
      try {
        const raw = localStorage.getItem(key);
        if (!raw) return;
        const parsed = JSON.parse(raw);
        if (!parsed || typeof parsed !== "object") return;
        if (!["saved", "products", "tasks", "moneyRows", "form", "draft"].some((field) => field in parsed)) return;
        found.push(normalizeWorkspace(parsed));
        usedKeys.push(key);
      } catch {
      }
    });
    if (!found.length) return { data: normalizeWorkspace(), usedKeys: [] };
    const primary = found[0];
    const merged = {
      ...primary,
      saved: mergeUnique(found.flatMap((item) => item.saved), (item) => item.id || `${item.productName || ""}:${item.createdAt || ""}`),
      products: mergeUnique(found.flatMap((item) => item.products), (item) => item.id || String(item.productName || "").trim().toLowerCase()),
      moneyRows: mergeUnique(found.flatMap((item) => item.moneyRows), (item) => item.id || `${item.type || ""}:${item.date || ""}:${item.amount || ""}`)
    };
    const draftSource = found.find((item) => item.form.productName || item.form.verifiedFeatures || item.checkText || item.moneyForm.amount);
    if (draftSource) {
      merged.form = draftSource.form;
      merged.pkg = draftSource.pkg;
      merged.moneyForm = draftSource.moneyForm;
      merged.checkText = draftSource.checkText;
      merged.search = draftSource.search;
      merged.draftProductId = draftSource.draftProductId;
    }
    return { data: normalizeWorkspace(merged), usedKeys };
  }
  function readRecoveryHistory() {
    try {
      const parsed = JSON.parse(localStorage.getItem(RECOVERY_KEY) || "[]");
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
  function saveWorkspace(data, makeRecovery = false) {
    const previous = localStorage.getItem(STORAGE_KEY);
    if (makeRecovery && previous) {
      try {
        const history = readRecoveryHistory();
        history.unshift({ capturedAt: (/* @__PURE__ */ new Date()).toISOString(), data: JSON.parse(previous) });
        localStorage.setItem(RECOVERY_KEY, JSON.stringify(history.slice(0, 8)));
      } catch {
      }
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...data, version: STORAGE_VERSION, savedAt: (/* @__PURE__ */ new Date()).toISOString() }));
  }
  function money(value) {
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(Number(value || 0));
  }
  function safeFeatureText(text) {
    return String(text || "").replace(/\$\s?\d+(?:\.\d{1,2})?/gi, "").replace(/\b(discount|sale|cheapest|lowest price|coupon|save money)\b/gi, "").replace(/\b(guaranteed|instantly|instant|100%|perfect|never fails)\b/gi, "designed to").replace(/\b(cure|cures|treat|treats|prevent|prevents|heal|heals|reverse|reverses|fix|fixes)\b/gi, "support").replace(/\s{2,}/g, " ").trim();
  }
  function scanCompliance(text, form = {}) {
    const source = String(text || "");
    const issues = [];
    const add = (id, severity, label, safer) => {
      if (!issues.some((item) => item.id === id)) issues.push({ id, severity, label, safer });
    };
    if (/\$\s?\d|\b(price|discount|sale|cheapest|lowest price|coupon|save money)\b/i.test(source)) {
      add("pricing", "block", "Pricing or promotional language detected.", "Remove the price or promotion and direct viewers to product details.");
    }
    if (/\b(guaranteed|instantly|100%|perfect|never fails)\b/i.test(source)) {
      add("absolute", "block", "Absolute performance claim detected.", "Use \u201Cdesigned to,\u201D \u201Cbuilt for,\u201D or a verified feature statement.");
    }
    if (/\b(cure|treat|prevent|heal|reverse|disease|weight loss|lose weight)\b/i.test(source)) {
      add("health", "block", "Health or medical claim detected.", "Use accurate support language and remove disease, treatment, and outcome claims.");
    }
    if (/\b(before and after|before\s*\/\s*after)\b/i.test(source)) {
      add("before-after", "block", "Before-and-after implication detected.", "Describe only verified product features without promising a personal outcome.");
    }
    if (/\b(earnings?|income|make money|financial freedom|get rich)\b/i.test(source)) {
      add("earnings", "block", "Income or earnings claim detected.", "Remove the financial outcome claim and describe only the creator workflow or verified product facts.");
    }
    if (/\b(better than|beats|superior to|versus|vs\.)\b/i.test(source)) {
      add("comparison", "review", "Promotional comparison language detected.", "Remove the competitor comparison and describe the promoted product's verified features on their own.");
    }
    if (/\b(only \d+ left|ends tonight|last chance)\b/i.test(source)) {
      add("scarcity", "block", "Scarcity or deadline language detected.", "Remove it unless the exact claim is verified as current.");
    }
    if (form.sampleReceived === false) {
      add("sample", "review", "Sample Received is not confirmed.", "Keep this as a planning draft and avoid first-person experience claims.");
    }
    if (/Wellness|Supplement|Oral|Dental|Skincare|Body-Applied|Kids|Tools/i.test(form.category || "")) {
      add("category", "review", `${form.category} requires additional review.`, "Use only verified product facts and the safest category-specific wording.");
    }
    if (/Electronics/i.test(form.category || "") || form.batteryPowered) {
      add("powered", "review", "Electrical or battery-powered product flagged for review.", "Use verified specifications and avoid unsupported safety or performance claims.");
    }
    return issues;
  }
  function flattenScript(pkg) {
    if (!pkg) return "";
    return [
      `DONE RITE CONTENT PACKAGE \u2014 ${pkg.productName}`,
      "",
      "HOOKS",
      ...pkg.hooks.map((hook, index) => `${index + 1}. ${hook}`),
      "",
      "VOICEOVER",
      pkg.voiceover,
      "",
      "ON-SCREEN TEXT",
      pkg.onScreenText,
      "",
      "CAPTION",
      pkg.caption,
      "",
      "HASHTAGS",
      pkg.hashtags,
      "",
      "CTA",
      pkg.cta,
      "",
      "THUMBNAIL",
      pkg.thumbnail,
      "",
      "AI IMAGE PROMPT",
      pkg.aiImagePrompt,
      "",
      "AI VIDEO PROMPT",
      pkg.aiVideoPrompt,
      "",
      "CROSS-PLATFORM CHECKLIST",
      pkg.crossPlatform,
      "",
      pkg.complianceNote
    ].join("\n");
  }
  function makePackage(form) {
    const product = form.productName.trim();
    const cleaned = safeFeatureText(form.verifiedFeatures);
    const feature = cleaned.split(/[\n.;]/).map((part) => part.trim()).filter(Boolean)[0] || "support a simpler everyday routine";
    const planning = !form.sampleReceived;
    const issues = scanCompliance(`${form.productName}
${form.verifiedFeatures}`, form);
    const changed = safeFeatureText(form.verifiedFeatures) !== form.verifiedFeatures.trim();
    if (changed) {
      issues.unshift({
        id: "rewritten",
        severity: "review",
        label: "Risky wording was removed from the verified-features field.",
        safer: "Review the cleaned wording before publishing."
      });
    }
    const prefix = planning ? "PLANNING DRAFT \u2014 SAMPLE NOT CONFIRMED\n\n" : "";
    const hooks = [
      `A simpler way to ${feature}\u2014without overcomplicating it.`,
      `Before you add another gadget, look at what ${product} is designed to do.`,
      `${product}: built around ${feature}.`
    ];
    const voiceover = `${prefix}Looking for a simple way to ${feature}? ${product} is designed around that job, with a product-focused setup that is easy to show in a short demo. Check the product details in the cart.`;
    const onScreenText = [
      "0\u20132s: WORTH A CLOSER LOOK?",
      `2\u20136s: ${product.toUpperCase()}`,
      `6\u201311s: DESIGNED TO ${feature.toUpperCase()}`,
      `11\u2013${form.duration}s: CHECK PRODUCT DETAILS`
    ].join("\n");
    const caption = `${planning ? "Planning draft: " : ""}A closer look at ${product} and the verified features it was designed around. Product details are available in the cart.`;
    const hashtags = "#ad #TikTokShop #GadgetFinds #ProductDemo #DoneRite";
    const cta = "Check the product details in the cart.";
    const thumbnail = "WORTH A CLOSER LOOK?";
    const aiImagePrompt = `Create a vertical 9:16 product-image-only visual for ${product}. Use a black, chrome, and electric-blue DONE RITE technology style. Show only the product and a clean feature-focused environment. No person, face, hands, price, discount badge, competitor branding, unsupported specification, or added product claim.`;
    const aiVideoPrompt = `Create a ${form.duration}-second vertical 9:16 product-image-only ${form.funnel} video for ${product}. Use three to five clean product shots, subtle electric-blue lighting, readable safe-zone text, and one cart-directed CTA. No face, hands, price, discount, false scarcity, competitor comparison, medical claim, absolute claim, or invented specification. Use only these verified details: ${cleaned || "No verified feature supplied; keep the presentation generic."}`;
    const crossPlatform = [
      "\u2610 TikTok: 9:16, product link/cart selected, content disclosure enabled",
      "\u2610 YouTube Short: remove TikTok-only cart wording and use an approved description link",
      "\u2610 Facebook/Instagram Reels: verify disclosure and link placement",
      "\u2610 Pinterest: link only to the approved YouTube or Amazon destination, never TikTok",
      "\u2610 Confirm music is licensed for commercial use"
    ].join("\n");
    const firstIssue = issues[0];
    const complianceNote = firstIssue ? `Compliance flags: ${issues.map((item) => item.label).join(" ")} Safer alternate: \u201C${firstIssue.safer}\u201D` : "Compliance flags: No automated wording flags found; safer alternate: keep all visible claims limited to verified product facts.";
    return {
      id: uid(),
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      productName: product,
      form: { ...form, verifiedFeatures: cleaned },
      hooks,
      voiceover,
      onScreenText,
      caption,
      hashtags,
      cta,
      thumbnail,
      aiImagePrompt,
      aiVideoPrompt,
      crossPlatform,
      complianceNote,
      issues,
      publishReady: form.sampleReceived && !issues.some((item) => item.severity === "block")
    };
  }
  function copyFallback(text) {
    const area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "");
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    area.setSelectionRange(0, text.length);
    const copied = document.execCommand("copy");
    document.body.removeChild(area);
    return copied;
  }
  async function copyText(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return true;
      }
      return copyFallback(text);
    } catch {
      return copyFallback(text);
    }
  }
  function Card({ children, className = "" }) {
    return /* @__PURE__ */ React.createElement("section", { className: `dr-card ${className}` }, children);
  }
  function Field({ label, children, help }) {
    return /* @__PURE__ */ React.createElement("div", { className: "dr-field" }, /* @__PURE__ */ React.createElement("label", { className: "dr-label" }, label), children, help ? /* @__PURE__ */ React.createElement("div", { className: "dr-help", style: { marginTop: 6 } }, help) : null);
  }
  function OutputCard({ title, text, onCopy }) {
    return /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "dr-output-head" }, /* @__PURE__ */ React.createElement("h3", null, title), /* @__PURE__ */ React.createElement("button", { className: "dr-copy", type: "button", onClick: () => onCopy(text, title) }, "Copy")), /* @__PURE__ */ React.createElement("div", { className: "dr-output" }, text));
  }
  function DoneRiteCreatorOS() {
    const [tab, setTab] = useState("home");
    const [ready, setReady] = useState(false);
    const [form, setForm] = useState(EMPTY_FORM);
    const [pkg, setPkg] = useState(null);
    const [saved, setSaved] = useState([]);
    const [products, setProducts] = useState([]);
    const [tasks, setTasks] = useState(DEFAULT_TASKS);
    const [moneyRows, setMoneyRows] = useState([]);
    const [moneyForm, setMoneyForm] = useState(EMPTY_MONEY);
    const [search, setSearch] = useState("");
    const [checkText, setCheckText] = useState("");
    const [copyStatus, setCopyStatus] = useState("");
    const [importStatus, setImportStatus] = useState("");
    const [draftProductId, setDraftProductId] = useState(null);
    const [lastSavedAt, setLastSavedAt] = useState(null);
    const [recoveryCount, setRecoveryCount] = useState(0);
    const [storageError, setStorageError] = useState("");
    const importRef = useRef(null);
    const stateRef = useRef(null);
    const lastRecoveryRef = useRef(0);
    useEffect(() => {
      try {
        const { data, usedKeys } = readWorkspace();
        setSaved(data.saved);
        setProducts(data.products);
        setTasks(data.tasks);
        setMoneyRows(data.moneyRows);
        setForm(data.form);
        setPkg(data.pkg);
        setMoneyForm(data.moneyForm);
        setCheckText(data.checkText);
        setSearch(data.search);
        setDraftProductId(data.draftProductId);
        setTab(data.lastTab);
        setRecoveryCount(readRecoveryHistory().length);
        if (usedKeys.some((key) => key !== STORAGE_KEY)) {
          setImportStatus("Older DONE RITE records were found and migrated into the repaired save system.");
        }
      } catch {
        setStorageError("Saved data could not be read. Do not enter new records until a backup is restored.");
      } finally {
        setReady(true);
      }
    }, []);
    useEffect(() => {
      if (!ready) return;
      const data = {
        saved,
        products,
        tasks,
        moneyRows,
        form,
        pkg,
        moneyForm,
        checkText,
        search,
        draftProductId,
        lastTab: tab
      };
      stateRef.current = data;
      const timer = window.setTimeout(() => {
        try {
          const shouldSnapshot = Date.now() - lastRecoveryRef.current > 3e4;
          saveWorkspace(data, shouldSnapshot);
          if (shouldSnapshot) lastRecoveryRef.current = Date.now();
          setLastSavedAt(/* @__PURE__ */ new Date());
          setRecoveryCount(readRecoveryHistory().length);
          setStorageError("");
        } catch {
          setStorageError("Automatic saving failed. Export a backup before closing the app.");
        }
      }, 200);
      return () => window.clearTimeout(timer);
    }, [ready, saved, products, tasks, moneyRows, form, pkg, moneyForm, checkText, search, draftProductId, tab]);
    useEffect(() => {
      if (!ready) return void 0;
      const flush = () => {
        if (!stateRef.current) return;
        try {
          saveWorkspace(stateRef.current, false);
        } catch {
        }
      };
      window.addEventListener("pagehide", flush);
      document.addEventListener("visibilitychange", flush);
      return () => {
        window.removeEventListener("pagehide", flush);
        document.removeEventListener("visibilitychange", flush);
      };
    }, [ready]);
    useEffect(() => {
      if (!ready || !form.productName.trim()) return void 0;
      const timer = window.setTimeout(() => {
        setProducts((current) => {
          const normalizedName = form.productName.trim().toLowerCase();
          const existing = current.find((item) => item.id === draftProductId) || current.find((item) => String(item.productName || "").trim().toLowerCase() === normalizedName);
          const id = existing?.id || draftProductId || uid();
          if (!draftProductId) setDraftProductId(id);
          const record = {
            ...existing || {},
            id,
            productName: form.productName.trim(),
            category: form.category,
            verifiedFeatures: form.verifiedFeatures,
            sampleReceived: form.sampleReceived,
            batteryPowered: form.batteryPowered,
            funnel: form.funnel,
            duration: form.duration,
            status: form.sampleReceived ? "Ready to create" : "Draft auto-saved",
            updatedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          const unchanged = existing && ["productName", "category", "verifiedFeatures", "sampleReceived", "batteryPowered", "funnel", "duration", "status"].every((key) => existing[key] === record[key]);
          if (unchanged) return current;
          return [record, ...current.filter((item) => item.id !== id)];
        });
      }, 250);
      return () => window.clearTimeout(timer);
    }, [ready, form, draftProductId]);
    useEffect(() => {
      if (!copyStatus) return void 0;
      const timer = window.setTimeout(() => setCopyStatus(""), 3500);
      return () => window.clearTimeout(timer);
    }, [copyStatus]);
    const complianceResults = useMemo(() => scanCompliance(checkText), [checkText]);
    const filteredSaved = useMemo(() => {
      const q = search.trim().toLowerCase();
      if (!q) return saved;
      return saved.filter((item) => flattenScript(item).toLowerCase().includes(q));
    }, [saved, search]);
    const revenue = moneyRows.filter((row) => row.type !== "Expense").reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const expenses = moneyRows.filter((row) => row.type === "Expense").reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const completedTasks = tasks.filter((task) => task.done).length;
    const sampleCount = products.filter((product) => product.sampleReceived).length;
    const setValue = (key, value) => setForm((current) => ({ ...current, [key]: value }));
    const notifyCopy = async (text, label) => {
      const ok = await copyText(text);
      setCopyStatus(ok ? `${label} copied.` : "Copy was blocked. Press and hold the text, then choose Select All and Copy.");
    };
    const generate = () => {
      if (!form.productName.trim()) {
        setCopyStatus("Enter the product name first.");
        return;
      }
      const next = makePackage(form);
      setPkg(next);
      setProducts((current) => {
        const existing = current.find((item) => item.id === draftProductId) || current.find((item) => item.productName.toLowerCase() === form.productName.trim().toLowerCase());
        const record = {
          id: existing?.id || draftProductId || uid(),
          productName: form.productName.trim(),
          category: form.category,
          verifiedFeatures: safeFeatureText(form.verifiedFeatures),
          sampleReceived: form.sampleReceived,
          batteryPowered: form.batteryPowered,
          funnel: form.funnel,
          duration: form.duration,
          status: form.sampleReceived ? "Ready to create" : "Waiting for sample",
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        setDraftProductId(record.id);
        return [record, ...current.filter((item) => item.id !== existing?.id)];
      });
      setCopyStatus("Product and generated package saved automatically.");
    };
    const startNewProduct = () => {
      setForm({ ...EMPTY_FORM });
      setPkg(null);
      setDraftProductId(null);
      setCopyStatus("New product form ready. Every field will save automatically.");
    };
    const editProduct = (product) => {
      setDraftProductId(product.id);
      setForm({
        ...EMPTY_FORM,
        productName: product.productName || "",
        category: product.category || EMPTY_FORM.category,
        verifiedFeatures: product.verifiedFeatures || "",
        sampleReceived: Boolean(product.sampleReceived),
        batteryPowered: Boolean(product.batteryPowered),
        funnel: product.funnel || EMPTY_FORM.funnel,
        duration: product.duration || EMPTY_FORM.duration
      });
      setPkg(null);
      setTab("create");
      setCopyStatus(`${product.productName} opened for editing.`);
    };
    const savePackage = () => {
      if (!pkg) return;
      setSaved((current) => [pkg, ...current.filter((item) => item.id !== pkg.id)]);
      setCopyStatus("Content package saved on this device.");
    };
    const duplicatePackage = (item) => {
      const duplicate = { ...item, id: uid(), createdAt: (/* @__PURE__ */ new Date()).toISOString(), productName: `${item.productName} copy` };
      setSaved((current) => [duplicate, ...current]);
    };
    const deleteSaved = (id) => {
      if (window.confirm("Delete this saved content package?")) {
        setSaved((current) => current.filter((item) => item.id !== id));
      }
    };
    const deleteProduct = (id) => {
      if (window.confirm("Delete this product record?")) {
        setProducts((current) => current.filter((item) => item.id !== id));
        if (draftProductId === id) {
          setDraftProductId(null);
          setForm({ ...EMPTY_FORM });
          setPkg(null);
        }
      }
    };
    const addMoney = () => {
      const amount = Number(moneyForm.amount);
      if (!Number.isFinite(amount) || amount <= 0) {
        setCopyStatus("Enter a valid amount first.");
        return;
      }
      setMoneyRows((current) => [{ ...moneyForm, id: uid(), amount }, ...current]);
      setMoneyForm((current) => ({ ...EMPTY_MONEY, type: current.type, platform: current.platform }));
    };
    const exportBackup = () => {
      const backup = {
        version: STORAGE_VERSION,
        exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
        saved,
        products,
        tasks,
        moneyRows,
        form,
        pkg,
        moneyForm,
        checkText,
        search,
        draftProductId,
        lastTab: tab,
        recoveryHistory: readRecoveryHistory()
      };
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `done-rite-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
      link.click();
      URL.revokeObjectURL(url);
      setImportStatus("Backup downloaded.");
    };
    const importBackup = async (file) => {
      if (!file) return;
      try {
        const data = JSON.parse(await file.text());
        if (![1, 2].includes(Number(data.version))) throw new Error("Unsupported backup version");
        const restored = normalizeWorkspace(data);
        setSaved(restored.saved);
        setProducts(restored.products);
        setTasks(restored.tasks);
        setMoneyRows(restored.moneyRows);
        setForm(restored.form);
        setPkg(restored.pkg);
        setMoneyForm(restored.moneyForm);
        setCheckText(restored.checkText);
        setSearch(restored.search);
        setDraftProductId(restored.draftProductId);
        setTab(restored.lastTab);
        if (Array.isArray(data.recoveryHistory)) {
          localStorage.setItem(RECOVERY_KEY, JSON.stringify(data.recoveryHistory.slice(0, 8)));
        }
        saveWorkspace(restored, true);
        setRecoveryCount(readRecoveryHistory().length);
        setImportStatus("Backup restored successfully, including unfinished drafts.");
      } catch {
        setImportStatus("That file is not a valid DONE RITE backup.");
      }
    };
    const restoreLatestRecovery = () => {
      try {
        const latest = readRecoveryHistory()[0]?.data;
        if (!latest) {
          setImportStatus("No recovery snapshot is available yet.");
          return;
        }
        const restored = normalizeWorkspace(latest);
        setSaved(restored.saved);
        setProducts(restored.products);
        setTasks(restored.tasks);
        setMoneyRows(restored.moneyRows);
        setForm(restored.form);
        setPkg(restored.pkg);
        setMoneyForm(restored.moneyForm);
        setCheckText(restored.checkText);
        setSearch(restored.search);
        setDraftProductId(restored.draftProductId);
        setTab(restored.lastTab);
        setImportStatus("The latest automatic recovery snapshot was restored.");
      } catch {
        setImportStatus("The latest recovery snapshot could not be restored.");
      }
    };
    const sections = pkg ? [
      ["Hooks", pkg.hooks.map((hook, index) => `${index + 1}. ${hook}`).join("\n")],
      ["Voiceover", pkg.voiceover],
      ["On-screen text", pkg.onScreenText],
      ["Caption", pkg.caption],
      ["Hashtags", pkg.hashtags],
      ["CTA", pkg.cta],
      ["Thumbnail", pkg.thumbnail],
      ["AI image prompt", pkg.aiImagePrompt],
      ["AI video prompt", pkg.aiVideoPrompt],
      ["Cross-platform checklist", pkg.crossPlatform],
      ["Compliance note", pkg.complianceNote]
    ] : [];
    const tabs = [
      ["home", "Home"],
      ["create", "Quick Create"],
      ["check", "Compliance"],
      ["products", "Products"],
      ["saved", "Saved"],
      ["money", "Money"],
      ["settings", "Settings"]
    ];
    return /* @__PURE__ */ React.createElement("div", { className: "dr-shell" }, /* @__PURE__ */ React.createElement("style", null, CSS), /* @__PURE__ */ React.createElement("header", { className: "dr-header" }, /* @__PURE__ */ React.createElement("div", { className: "dr-wrap dr-brand" }, /* @__PURE__ */ React.createElement("div", { className: "dr-bolt", "aria-hidden": "true" }, "\u26A1"), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h1", { className: "dr-title" }, "DONE RITE Creator OS"), /* @__PURE__ */ React.createElement("p", { className: "dr-tagline" }, "Real Reviews. Real Gadgets. Done Rite."))), /* @__PURE__ */ React.createElement("div", { className: "dr-tabs", role: "tablist", "aria-label": "Creator OS sections" }, tabs.map(([id, label]) => /* @__PURE__ */ React.createElement("button", { key: id, className: "dr-tab", type: "button", role: "tab", "aria-selected": tab === id, onClick: () => setTab(id) }, label)))), /* @__PURE__ */ React.createElement("main", { className: "dr-wrap" }, /* @__PURE__ */ React.createElement("div", { className: "dr-status", role: "status", "aria-live": "polite" }, copyStatus), storageError && /* @__PURE__ */ React.createElement(Card, { className: "dr-flag dr-block" }, /* @__PURE__ */ React.createElement("h3", null, "Save warning"), /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, storageError)), tab === "home" && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("h2", null, "Start My Day"), /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "One dashboard. One clear daily mission. Prioritize money, time, growth, platform rules, and AI assistance.")), /* @__PURE__ */ React.createElement("div", { className: "dr-grid", style: { marginTop: 12 } }, /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "dr-label" }, "Net revenue"), /* @__PURE__ */ React.createElement("div", { className: "dr-metric" }, money(revenue - expenses))), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "dr-label" }, "Daily progress"), /* @__PURE__ */ React.createElement("div", { className: "dr-metric" }, completedTasks, "/", tasks.length)), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "dr-label" }, "Products"), /* @__PURE__ */ React.createElement("div", { className: "dr-metric" }, products.length)), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "dr-label" }, "Samples received"), /* @__PURE__ */ React.createElement("div", { className: "dr-metric" }, sampleCount))), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "dr-output-head" }, /* @__PURE__ */ React.createElement("h3", null, "Today\u2019s Mission"), /* @__PURE__ */ React.createElement("span", { className: "dr-pill" }, lastSavedAt ? "Everything saved" : "Starting save system")), lastSavedAt && /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "Last automatic save: ", lastSavedAt.toLocaleTimeString()), /* @__PURE__ */ React.createElement("div", { className: "dr-list" }, tasks.map((task) => /* @__PURE__ */ React.createElement("label", { className: "dr-item", key: task.id }, /* @__PURE__ */ React.createElement("span", { className: "dr-check" }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: task.done, onChange: () => setTasks((current) => current.map((item) => item.id === task.id ? { ...item, done: !item.done } : item)) }), /* @__PURE__ */ React.createElement("span", null, task.label))))))), tab === "create" && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "dr-output-head" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h2", null, "Quick Create"), /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "Every field saves automatically while you type. Enter only verified product information.")), /* @__PURE__ */ React.createElement("button", { className: "dr-copy", type: "button", onClick: startNewProduct }, "New Product")), /* @__PURE__ */ React.createElement("div", { style: { height: 14 } }), /* @__PURE__ */ React.createElement(Field, { label: "Product name" }, /* @__PURE__ */ React.createElement("input", { className: "dr-input", value: form.productName, onChange: (event) => setValue("productName", event.target.value), placeholder: "Example: rechargeable work light" })), /* @__PURE__ */ React.createElement(Field, { label: "Category" }, /* @__PURE__ */ React.createElement("select", { className: "dr-select", value: form.category, onChange: (event) => setValue("category", event.target.value) }, CATEGORIES.map((category) => /* @__PURE__ */ React.createElement("option", { key: category }, category)))), /* @__PURE__ */ React.createElement(Field, { label: "Verified features", help: "Do not paste seller hype, prices, discounts, unsupported specifications, or medical claims." }, /* @__PURE__ */ React.createElement("textarea", { className: "dr-textarea", value: form.verifiedFeatures, onChange: (event) => setValue("verifiedFeatures", event.target.value), placeholder: "One verified feature per line" })), /* @__PURE__ */ React.createElement("div", { className: "dr-row" }, /* @__PURE__ */ React.createElement(Field, { label: "Funnel" }, /* @__PURE__ */ React.createElement("select", { className: "dr-select", value: form.funnel, onChange: (event) => setValue("funnel", event.target.value) }, /* @__PURE__ */ React.createElement("option", null, "BOF"), /* @__PURE__ */ React.createElement("option", null, "TOF"))), /* @__PURE__ */ React.createElement(Field, { label: "Duration" }, /* @__PURE__ */ React.createElement("select", { className: "dr-select", value: form.duration, onChange: (event) => setValue("duration", event.target.value) }, /* @__PURE__ */ React.createElement("option", null, "7"), /* @__PURE__ */ React.createElement("option", null, "10"), /* @__PURE__ */ React.createElement("option", null, "15"), /* @__PURE__ */ React.createElement("option", null, "20"), /* @__PURE__ */ React.createElement("option", null, "30")))), /* @__PURE__ */ React.createElement("div", { className: "dr-field" }, /* @__PURE__ */ React.createElement("label", { className: "dr-check" }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: form.sampleReceived, onChange: (event) => setValue("sampleReceived", event.target.checked) }), /* @__PURE__ */ React.createElement("span", null, "I have received this sample. If unchecked, the output stays a planning draft."))), /* @__PURE__ */ React.createElement("div", { className: "dr-field" }, /* @__PURE__ */ React.createElement("label", { className: "dr-check" }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: form.batteryPowered, onChange: (event) => setValue("batteryPowered", event.target.checked) }), /* @__PURE__ */ React.createElement("span", null, "This product is electrical or battery-powered."))), /* @__PURE__ */ React.createElement("button", { className: "dr-button", type: "button", onClick: generate }, "Generate Content Package"), /* @__PURE__ */ React.createElement("p", { className: "dr-help", style: { marginBottom: 0, color: COLORS.green } }, form.productName.trim() ? "Draft is being preserved in the Product Vault." : "Start typing a product name; the draft will be preserved automatically.")), pkg && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Card, { className: pkg.publishReady ? "dr-clear" : "dr-flag" }, /* @__PURE__ */ React.createElement("div", { className: "dr-output-head" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", null, pkg.publishReady ? "Automated check passed" : "Review before publishing"), /* @__PURE__ */ React.createElement("div", { className: "dr-help" }, "Automated checks cannot verify seller facts or current platform eligibility.")), /* @__PURE__ */ React.createElement("span", { className: "dr-pill" }, pkg.form.funnel, " \xB7 ", pkg.form.duration, "s")), /* @__PURE__ */ React.createElement("div", { className: "dr-row" }, /* @__PURE__ */ React.createElement("button", { className: "dr-button", type: "button", onClick: () => notifyCopy(flattenScript(pkg), "Everything") }, "Copy Everything"), /* @__PURE__ */ React.createElement("button", { className: "dr-copy", type: "button", onClick: () => notifyCopy(pkg.aiVideoPrompt, "AI prompt") }, "Copy AI Prompt"), /* @__PURE__ */ React.createElement("button", { className: "dr-copy", type: "button", onClick: savePackage }, "Save Package"))), sections.map(([title, text]) => /* @__PURE__ */ React.createElement(OutputCard, { key: title, title, text, onCopy: notifyCopy })))), tab === "check" && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("h2", null, "Compliance Center"), /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "Paste a hook, script, caption, or on-screen text. This is a wording screen, not a guarantee of platform approval."), /* @__PURE__ */ React.createElement("div", { style: { height: 12 } }), /* @__PURE__ */ React.createElement("textarea", { className: "dr-textarea", value: checkText, onChange: (event) => setCheckText(event.target.value), placeholder: "Paste content to check" })), checkText && complianceResults.length === 0 && /* @__PURE__ */ React.createElement(Card, { className: "dr-clear" }, /* @__PURE__ */ React.createElement("h3", null, "No automated wording flags found"), /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "Still verify product facts, eligibility, disclosure, footage, audio rights, and current platform rules.")), complianceResults.map((issue) => /* @__PURE__ */ React.createElement(Card, { key: issue.id, className: issue.severity === "block" ? "dr-flag dr-block" : "dr-flag" }, /* @__PURE__ */ React.createElement("h3", { style: { color: issue.severity === "block" ? COLORS.red : COLORS.amber } }, issue.label), /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "Safer alternate: ", issue.safer)))), tab === "products" && /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "dr-output-head" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h2", null, "Product & Sample Vault"), /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "Track received samples and the next content action.")), /* @__PURE__ */ React.createElement("span", { className: "dr-pill" }, products.length, " products")), /* @__PURE__ */ React.createElement("div", { className: "dr-list" }, products.length === 0 && /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "Create your first product in Quick Create."), products.map((product) => /* @__PURE__ */ React.createElement("div", { className: "dr-item", key: product.id }, /* @__PURE__ */ React.createElement("div", { className: "dr-item-main" }, /* @__PURE__ */ React.createElement("div", { className: "dr-item-title" }, product.productName), /* @__PURE__ */ React.createElement("div", { className: "dr-help" }, product.category, " \xB7 ", product.status), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 8 } }, /* @__PURE__ */ React.createElement("span", { className: "dr-pill" }, product.sampleReceived ? "Sample received" : "Waiting for sample"))), /* @__PURE__ */ React.createElement("div", { className: "dr-row", style: { flex: "0 1 190px" } }, /* @__PURE__ */ React.createElement("button", { className: "dr-copy", type: "button", onClick: () => editProduct(product) }, "Edit"), /* @__PURE__ */ React.createElement("button", { className: "dr-danger", type: "button", onClick: () => deleteProduct(product.id) }, "Delete")))))), tab === "saved" && /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "dr-output-head" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h2", null, "Saved Creations"), /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "Search, copy, duplicate, or delete packages stored on this device.")), /* @__PURE__ */ React.createElement("span", { className: "dr-pill" }, saved.length, " saved")), /* @__PURE__ */ React.createElement("input", { className: "dr-input", value: search, onChange: (event) => setSearch(event.target.value), placeholder: "Search product or script" }), /* @__PURE__ */ React.createElement("div", { className: "dr-list", style: { marginTop: 12 } }, filteredSaved.length === 0 && /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "No matching saved packages."), filteredSaved.map((item) => /* @__PURE__ */ React.createElement("div", { className: "dr-item", key: item.id }, /* @__PURE__ */ React.createElement("div", { className: "dr-item-main" }, /* @__PURE__ */ React.createElement("div", { className: "dr-item-title" }, item.productName), /* @__PURE__ */ React.createElement("div", { className: "dr-help" }, new Date(item.createdAt).toLocaleString())), /* @__PURE__ */ React.createElement("div", { className: "dr-row", style: { flex: "0 1 290px" } }, /* @__PURE__ */ React.createElement("button", { className: "dr-copy", type: "button", onClick: () => notifyCopy(flattenScript(item), item.productName) }, "Copy"), /* @__PURE__ */ React.createElement("button", { className: "dr-copy", type: "button", onClick: () => duplicatePackage(item) }, "Duplicate"), /* @__PURE__ */ React.createElement("button", { className: "dr-danger", type: "button", onClick: () => deleteSaved(item.id) }, "Delete")))))), tab === "money" && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "dr-grid" }, /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "dr-label" }, "Revenue"), /* @__PURE__ */ React.createElement("div", { className: "dr-metric" }, money(revenue))), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "dr-label" }, "Expenses"), /* @__PURE__ */ React.createElement("div", { className: "dr-metric", style: { color: COLORS.amber } }, money(expenses)))), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("h2", null, "Money Center"), /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "A simple record keeper\u2014not financial advice."), /* @__PURE__ */ React.createElement("div", { style: { height: 12 } }), /* @__PURE__ */ React.createElement("div", { className: "dr-row" }, /* @__PURE__ */ React.createElement(Field, { label: "Type" }, /* @__PURE__ */ React.createElement("select", { className: "dr-select", value: moneyForm.type, onChange: (event) => setMoneyForm((current) => ({ ...current, type: event.target.value })) }, /* @__PURE__ */ React.createElement("option", null, "Affiliate revenue"), /* @__PURE__ */ React.createElement("option", null, "Brand deal"), /* @__PURE__ */ React.createElement("option", null, "Expense"))), /* @__PURE__ */ React.createElement(Field, { label: "Platform" }, /* @__PURE__ */ React.createElement("select", { className: "dr-select", value: moneyForm.platform, onChange: (event) => setMoneyForm((current) => ({ ...current, platform: event.target.value })) }, /* @__PURE__ */ React.createElement("option", null, "TikTok Shop"), /* @__PURE__ */ React.createElement("option", null, "Amazon"), /* @__PURE__ */ React.createElement("option", null, "YouTube"), /* @__PURE__ */ React.createElement("option", null, "Facebook"), /* @__PURE__ */ React.createElement("option", null, "Instagram"), /* @__PURE__ */ React.createElement("option", null, "Pinterest"), /* @__PURE__ */ React.createElement("option", null, "UGC"), /* @__PURE__ */ React.createElement("option", null, "Other")))), /* @__PURE__ */ React.createElement("div", { className: "dr-row" }, /* @__PURE__ */ React.createElement(Field, { label: "Amount" }, /* @__PURE__ */ React.createElement("input", { className: "dr-input", type: "number", inputMode: "decimal", min: "0", step: "0.01", value: moneyForm.amount, onChange: (event) => setMoneyForm((current) => ({ ...current, amount: event.target.value })) })), /* @__PURE__ */ React.createElement(Field, { label: "Date" }, /* @__PURE__ */ React.createElement("input", { className: "dr-input", type: "date", value: moneyForm.date, onChange: (event) => setMoneyForm((current) => ({ ...current, date: event.target.value })) }))), /* @__PURE__ */ React.createElement("button", { className: "dr-button", type: "button", onClick: addMoney }, "Save Record")), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "dr-list" }, moneyRows.length === 0 && /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "No money records yet."), moneyRows.map((row) => /* @__PURE__ */ React.createElement("div", { className: "dr-item", key: row.id }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "dr-item-title" }, row.type, " \xB7 ", row.platform), /* @__PURE__ */ React.createElement("div", { className: "dr-help" }, row.date)), /* @__PURE__ */ React.createElement("strong", { style: { color: row.type === "Expense" ? COLORS.amber : COLORS.green } }, money(row.amount))))))), tab === "settings" && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("h2", null, "Backup & Restore"), /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "Backups now include product drafts, generated packages, compliance text, money-entry drafts, products, saved creations, tasks, and records."), /* @__PURE__ */ React.createElement("div", { className: "dr-row", style: { marginTop: 14 } }, /* @__PURE__ */ React.createElement("button", { className: "dr-button", type: "button", onClick: exportBackup }, "Export Backup"), /* @__PURE__ */ React.createElement("button", { className: "dr-copy", type: "button", onClick: () => importRef.current?.click() }, "Restore Backup")), /* @__PURE__ */ React.createElement("div", { className: "dr-row", style: { marginTop: 10 } }, /* @__PURE__ */ React.createElement("button", { className: "dr-copy", type: "button", onClick: restoreLatestRecovery }, "Restore Latest Recovery"), /* @__PURE__ */ React.createElement("span", { className: "dr-pill" }, recoveryCount, " recovery snapshots")), /* @__PURE__ */ React.createElement("input", { ref: importRef, type: "file", accept: "application/json,.json", hidden: true, onChange: (event) => importBackup(event.target.files?.[0]) }), importStatus && /* @__PURE__ */ React.createElement("p", { className: "dr-help", style: { color: COLORS.green } }, importStatus)), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("h3", null, "Permanent Playbook Rules"), /* @__PURE__ */ React.createElement("div", { className: "dr-output", style: { marginTop: 10 } }, "No pricing or discount language. No competitor comparisons. No unsupported claims. Health content uses support language only. Every affiliate hashtag set includes #ad. Product-image-only by default. Confirm Sample Received before publish-ready first-person content.")), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("h3", null, "Save System v2"), /* @__PURE__ */ React.createElement("p", { className: "dr-help" }, "The repaired system saves unfinished typing, generated work, product records, and business records. It also checks older DONE RITE storage keys and keeps rolling recovery snapshots.")))), /* @__PURE__ */ React.createElement("nav", { className: "dr-nav", "aria-label": "Bottom navigation" }, /* @__PURE__ */ React.createElement("div", { className: "dr-nav-inner" }, tabs.map(([id, label]) => /* @__PURE__ */ React.createElement("button", { key: id, type: "button", "aria-current": tab === id ? "page" : void 0, onClick: () => setTab(id) }, label)))));
  }
  globalThis.DoneRiteCreatorOS = DoneRiteCreatorOS;
})();
